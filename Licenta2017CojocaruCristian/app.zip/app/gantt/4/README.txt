A Pen created at CodePen.io. You can find this one at http://codepen.io/pursianKatze/pen/OmbWvZ.

 Just a chart I put together for a Stack Overflow question about how to make horizontal stacked charts.