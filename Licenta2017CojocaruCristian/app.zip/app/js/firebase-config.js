	  // Initialize Firebase
	  var config = {
	  	apiKey: "AIzaSyDkVEz0t4IP_s4_Dg-0nEHCHgm6gBYEa7w",
	  	authDomain: "uberphasic.firebaseapp.com",
	  	databaseURL: "https://uberphasic.firebaseio.com",
	  	projectId: "uberphasic",
	  	storageBucket: "uberphasic.appspot.com",
	  	messagingSenderId: "731789591192"
	  };
	  firebase.initializeApp(config);
